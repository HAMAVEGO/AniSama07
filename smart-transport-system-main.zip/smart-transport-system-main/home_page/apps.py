from django.apps import AppConfig


class HomepageConfig(AppConfig):
    name = 'home_page'
