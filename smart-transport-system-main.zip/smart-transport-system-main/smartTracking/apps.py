from django.apps import AppConfig


class SmarttrackingConfig(AppConfig):
    name = 'smartTracking'
